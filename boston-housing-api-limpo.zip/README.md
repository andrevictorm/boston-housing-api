# Boston Housing Price Prediction API

API com FastAPI

- Batch prediction
- API Key
- Modelo RandomForest

POST /predict
Header: X-API-Key: boston_2025_secret_8f9d2a1c9e7b3f6d5a4c8e2f1d0b9a8e7c6d5f4

Docs: /docs
